using GitPushr.Standard.Models;
namespace GitPushr.Standard
{
    public partial class Configuration
    {

        //The base Uri for API calls
        public static string BaseUri = "https://hwnfjlu3y6.execute-api.us-west-2.amazonaws.com/dev";

        //Git username
        //TODO: Replace the XUsername with an appropriate value
        public static string XUsername = "";

        //Git token
        //TODO: Replace the XPassword with an appropriate value
        public static string XPassword = "";

    }
}